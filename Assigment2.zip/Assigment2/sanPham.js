let sanPham = [
    {
        id: 1,
        name: 'iPhone 9',
        price: 700
    },
    {
        id: 2,
        name: 'Samsung',
        price: 400
    },
    {
        id: 3,
        name: 'Nokia',
        price: 100
    },
    {
        id: 4,
        name: 'Sony Xperia',
        price: 450
    },
    {
        id: 5,
        name: 'Motorola',
        price: 180
    },
    {
        id: 6,
        name: 'Oppo',
        price: 600
    },
    {
        id: 7,
        name: 'bPhone',
        price: 90
    },
];